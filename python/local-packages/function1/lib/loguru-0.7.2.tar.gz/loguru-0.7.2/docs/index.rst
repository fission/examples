.. include:: ../README.rst
   :end-before: end-of-readme-intro

Table of contents
=================

.. toctree::
   :includehidden:
   :maxdepth: 2

   overview.rst
   api.rst
   resources.rst
   project.rst
