Project Information
===================

.. toctree::

   project/contributing.rst
   project/license.rst
   project/changelog.rst
