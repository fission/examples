:orphan:

.. _type-hints-source:

Source code for type hints
==========================

.. include:: ../../loguru/__init__.pyi
   :literal:
