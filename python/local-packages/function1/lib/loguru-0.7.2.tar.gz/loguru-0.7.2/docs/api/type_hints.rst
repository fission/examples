.. _type-hints:

Type hints
==========

.. automodule:: autodoc_stub_file.loguru


See also: :ref:`type-hints-source`.
