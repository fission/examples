``loguru.logger``
=================

.. automodule:: loguru._logger

.. autoclass:: loguru._logger.Logger()
   :members:
