module.exports = {
  reactStrictMode: true,
  basePath: '/nextapp',
  distDir: '.next',
}
