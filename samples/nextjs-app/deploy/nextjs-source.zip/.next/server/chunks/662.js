exports.id = 662;
exports.ids = [662];
exports.modules = {

/***/ 1662:
/***/ (function(module) {

"use strict";
module.exports = JSON.parse('[{"title":"Fission WebSocket Sample","slug":"websocket-sample","author":"Gaurav Gahlot","description":"In this post we will look into how we can develop a simple a web socket based chat application using Fission functions. Fission’s NodeJS environment now has built in support for WebSocket. So, we are going to use this environment to power our simple web based chat application."},{"title":"Headless Chrome with Puppeteer in a function","slug":"chrome-puppeteer-function","author":"Vishal Biyani","description":"Running chrome headless is useful for various test automation tasks but running a headless Chrome in Docker can be tricky (More details here). Also the this Github issue has some good insights on the issues you might face. This blog shows running headless chrome in a fission function. You can find the working example with code etc. in examples repo here."},{"title":"Using gVisor with Fission","slug":"fission-gvisor","author":"Harsh Thakur","description":"In order to have the security of VMs and speed of containers, projects like gVisor and kata containers have risen. In this post, we’ll take a look at gVisor provides an application kernel for containers. It provides a runtime which can be used by Kubernetes. To understand more about how gVisor provides security, please go through this."},{"title":"Monitoring Fission logs with Grafana Loki","slug":"log-monitoring","author":"Sahil Lakhwani","description":"Proper logging in a software is a quick and systematic way to inform the state of the software. Although the definition of ‘logs’ remains the same along years in software engineering, the scope of what logs are used is has always been increasing."},{"title":"Setting Ingress for your Functions","slug":"ingress","author":"Ta-Ching Chen","description":"Fission previously supported ingress. However, it lacked support for TLS, host field, and ingress annotations. Now with version 1.6, all three are supported. In this blog post, we will cover all three of the new features. But first, let’s talk about ingress some more."},{"title":"Function builders also support PodSpec now","slug":"fission-builder-podspec","author":"Vivek Singh","description":"In this post we will be looking into how do we use PodSpec in builder so that the deployment that will be created for the builder will have podspec that we mention in the environment for builder."}]');

/***/ })

};
;